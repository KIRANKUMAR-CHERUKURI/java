import java.io.*;

class Book {
    private String bookTitle;
    private String author;
    private String isbn;

    public Book(String bookTitle, String author, String isbn) {
        this.bookTitle = bookTitle;
        this.author = author;
        this.isbn = isbn;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public String getAuthor() {
        return author;
    }

    public String getISBN() {
        return isbn;
    }

    @Override
    public String toString() {
        return "Book Title: " + bookTitle + ", Author: " + author + ", ISBN: " + isbn;
    }
}

public class LibraryManagementSystem {
    private static final String FILE_NAME = "library_details.txt";
    private static BufferedReader bufferedReader;
    private static BufferedWriter bufferedWriter;

    public static void main(String[] args) {
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(System.in));
            bufferedWriter = new BufferedWriter(new FileWriter(FILE_NAME, true)); // Append mode
            System.out.print("Enter the username:");
            java.util.Scanner scl=new java.util.Scanner(System.in);
            String username=scl.next();
            //System.out.println();
            System.out.print("Enter the password:");
            String password=scl.next();
            System.out.println();
            //java.util.Scanner scl=new java.util.Scanner(System.in);
            if (login.checkLogin(username, password) == true) {
                System.out.println("You are logged in");
                int choice;
                while (true) {
                    System.out.println("\n--- Library Management System ---");
                    System.out.println("1. Add a book");
                    System.out.println("2. View all books");
                    System.out.println("3. Search for a book");
                    System.out.println("4. Exit");
                    System.out.print("Enter your choice: ");
                    //choice = Integer.parseInt(bufferedReader.readLine());
                    java.util.Scanner sc = new java.util.Scanner(System.in);
                    choice = sc.nextInt();

                    if (choice == 1) {
                        System.out.println("\n--- Add a book ---");
                        System.out.print("Enter book title: ");
                        String bookTitle = bufferedReader.readLine();
                        System.out.print("Enter author: ");
                        String author = bufferedReader.readLine();
                        System.out.print("Enter ISBN: ");
                        String isbn = bufferedReader.readLine();

                        Book book = new Book(bookTitle, author, isbn);

                        // Write book details to the text file
                        bufferedWriter.write(book.toString());
                        bufferedWriter.newLine();
                        bufferedWriter.flush();

                        System.out.println("Book added successfully!");
                    } else if (choice == 2) {
                        System.out.println("\n--- View all books ---");

                        // Read all book details from the text file and display
                        bufferedReader = new BufferedReader(new FileReader(FILE_NAME));
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            System.out.println(line);
                        }
                    } else if (choice == 3) {
                        System.out.println("\n--- Search for a book ---");
                        System.out.println("Search by:");
                        System.out.println("1. ID");
                        System.out.println("2. Author");
                        System.out.println("3. Book Name");
                        System.out.print("Enter your choice: ");
                        java.util.Scanner sc1 = new java.util.Scanner(System.in);
                        int searchChoice = sc1.nextInt();

                        if (searchChoice == 1) {
                            System.out.print("Enter book ID: ");
                            String bookId = bufferedReader.readLine();

                            // Search for book by ID in the text file
                            bufferedReader = new BufferedReader(new FileReader(FILE_NAME));
                            String line;
                            boolean found = false;
                            while ((line = bufferedReader.readLine()) != null) {
                                if (line.contains("ID: " + bookId)) {
                                    System.out.println("Book found: " + line);
                                    found = true;
                                }
                            }
                            bufferedReader.close();

                            if (!found) {
                                System.out.println("No books found with ID: " + bookId);
                            }
                        } else if (searchChoice == 2) {
                            System.out.print("Enter author name: ");
                            String author = bufferedReader.readLine();
                            // Search for book by author name in the text file
                            bufferedReader = new BufferedReader(new FileReader(FILE_NAME));
                            String line;
                            boolean found = false;
                            while ((line = bufferedReader.readLine()) != null) {
                                if (line.contains("Author: " + author)) {
                                    System.out.println("Book found: " + line);
                                    found = true;
                                }
                            }
                            bufferedReader.close();

                            if (!found) {
                                System.out.println("No books found with author: " + author);
                            }
                        } else if (searchChoice == 3) {
                            System.out.print("Enter book name: ");
                            String bookName = bufferedReader.readLine();

                            // Search for book by book name in the text file
                            bufferedReader = new BufferedReader(new FileReader(FILE_NAME));
                            String line;
                            boolean found = false;
                            while ((line = bufferedReader.readLine()) != null) {
                                if (line.contains("Book Title: " + bookName)) {
                                    System.out.println("Book found: " + line);
                                    found = true;
                                }
                            }
                            bufferedReader.close();

                            if (!found) {
                                System.out.println("No books found with name: " + bookName);
                            }
                        } else {
                            System.out.println("Invalid choice! Please try again.");
                        }
                    } else if (choice == 4) {
                        System.out.println("\nExiting Library Management System...");
                        break;
                    } else {
                        System.out.println("Invalid choice! Please try again.");
                    }
                }
            }
            else System.out.println("Wromg details Enetered");

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (bufferedWriter != null) {
                    bufferedWriter.close();
                }
            } catch (IOException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}

