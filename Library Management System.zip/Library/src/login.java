import java.util.Scanner;
public class login {
    public static boolean checkLogin(String a,String b)
    {
        //Scanner sc=new Scanner(System.in);
        String[][] users = {
                {"Kiran", "kc5577"},
                {"Akash", "ak123"},
                {"Kuanl", "kg899"},
                {"cse310", "java"}
        };

        // Prompt the user to enter a username and password
        String inputUsername = a; // Example input
        String inputPassword = b; // Example input

        // Loop through the 2D array to check if the entered username and password match
        boolean isAuthenticated = false;
        for (String[] user : users) {
            if (user[0].equals(inputUsername) && user[1].equals(inputPassword)) {
                isAuthenticated = true;
                break;
            }
        }


        // Display the authentication result
        return isAuthenticated;
    }

}
